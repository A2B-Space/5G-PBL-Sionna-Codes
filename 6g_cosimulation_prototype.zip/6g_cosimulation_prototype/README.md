# 6G Environment-Aware Semantic Communication Co-Simulation Prototype

This is a drop-in dashboard/integration layer. It does **not** copy, rewrite, or package the DeepSense project or the Sionna project.

## What it connects

- DeepSense semantic outputs exported as CSV, JSON or JSONL.
- Existing Sionna S1-S8 physical-layer artifacts, especially `snapshot_metadata.csv`, with optional S7 beam-tracking summaries.
- A lightweight semantic-priority / channel-conditioned **application-layer packet-budget** controller.

## Important boundary

The current Sionna dataset records a dimensionless beamformed channel-gain metric `|h^T w|^2`, not calibrated received power or SNR. This prototype replays the already-generated Sionna channel results; it does not rerun GPU ray tracing. The transmission controller is an application-layer abstraction and does not calculate BER, modulation, coding, RF waveforms, or measured latency.

## 1. Put this folder on the Sionna laptop

Extract this prototype anywhere, for example:

```bash
mkdir -p ~/6g_cosimulation
# Extract/copy the contents of this bundle into ~/6g_cosimulation
```

The Sionna project is expected at `~/sionna_project` by default, or change the path in the dashboard sidebar. The Sionna folder must contain `s6_physical_layer_dataset/snapshot_metadata.csv` or another `snapshot_metadata.csv` export.

## 2. Activate the existing Sionna environment

```bash
cd ~/sionna_project
source .venv/bin/activate
python -m pip install streamlit plotly
```

Do not reinstall Sionna, Mitsuba, Dr.Jit, PyTorch, or TensorFlow for this dashboard.

## 3. Launch the dashboard

```bash
cd ~/6g_cosimulation
streamlit run dashboard/app.py --server.address 0.0.0.0
```

Open the local URL printed by Streamlit (normally `http://localhost:8501`).

## 4. Connect the existing DeepSense folder without ZIP

The uploaded project packaging script identifies the local project path as:

`C:\Users\nanda\EnvironmentSemanticProject`

In WSL2 this is normally:

`/mnt/c/Users/nanda/EnvironmentSemanticProject`

Paste that path into the DeepSense folder field in the dashboard. The dashboard scans in place and does not copy large files. It looks for compact CSV/JSON/JSONL semantic outputs with names suggesting predictions, detections, objects, semantic results or inference.

You can also upload one small semantic export directly from the dashboard. Recommended columns:

- Required: `class` / `label` / `category` / `object_class`
- Recommended: `confidence` / `score`
- Best join key: `sample_id`
- Alternative join keys: `scene_id`, `trajectory_id`, `snapshot`
- Optional: `object_id`, object position or bounding-box coordinates

If the DeepSense file contains detections for one frame only and has no synchronization keys, the dashboard exposes an explicit manual mapping checkbox. Use it only after verifying that the chosen DeepSense frame corresponds to the selected Sionna snapshot. Row order alone is not a valid join key.

## 5. Quick read-only DeepSense inspection (no ZIP)

If the dashboard does not detect a semantic export, run:

```bash
python tools/inspect_deepsense.py --root /mnt/c/Users/nanda/EnvironmentSemanticProject
```

This prints likely runner scripts and small semantic-export candidates. It does not copy or modify project files. Share only the `LIKELY_EXECUTION_SCRIPTS` and `LIKELY_SEMANTIC_EXPORTS` sections if a direct model-runner hook is needed.

## 6. What to demonstrate

1. Sionna physical-layer dataset loaded, with blocked/unblocked scenario selection.
2. Receiver snapshot selection and channel/beam diagnostics.
3. DeepSense semantic detections loaded and aligned to a Sionna sample.
4. Three policy comparisons: conventional fixed payload, semantic-priority, and joint semantic + channel-aware.
5. Object-level delivery decisions and CSV export.

## Research honesty / demo wording

For this prototype say: **"We replay the Sionna RT physical-layer channel dataset and couple each keyed snapshot to DeepSense semantic detections. A channel-conditioned semantic controller then adapts the application payload budget and object detail."** Do not describe this version as live RF co-simulation or a waveform/BER simulator.
