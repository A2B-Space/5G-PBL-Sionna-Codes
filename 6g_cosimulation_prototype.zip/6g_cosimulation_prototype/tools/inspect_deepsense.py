#!/usr/bin/env python3
"""Fast, read-only inventory of a local DeepSense project; never copies model/data files."""
from __future__ import annotations
import argparse
import os
from pathlib import Path

SKIP = {".git", ".venv", "venv", "env", "__pycache__", "node_modules", ".pytest_cache", "checkpoints", "weights", "models", "raw_data", "raw", "videos", "pointclouds", "cache"}
HINTS = ("semantic", "detect", "predict", "infer", "object", "result", "output", "export")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--root", required=True, help="DeepSense project directory")
    args = ap.parse_args()
    root = Path(args.root).expanduser().resolve()
    if not root.exists():
        raise SystemExit(f"Project folder not found: {root}")
    scripts, data = [], []
    total = 0
    for current, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in SKIP]
        folder = Path(current)
        for name in files:
            p = folder / name
            try:
                size = p.stat().st_size
            except OSError:
                continue
            total += size
            rel = str(p.relative_to(root))
            if p.suffix.lower() == ".py":
                low = p.name.lower()
                if any(x in low for x in ("main", "run", "infer", "predict", "detect", "eval", "test")):
                    scripts.append((size, rel))
            elif p.suffix.lower() in {".csv", ".json", ".jsonl", ".parquet"} and any(x in p.name.lower() for x in HINTS) and size <= 150 * 1024 * 1024:
                data.append((size, rel))
    print(f"ROOT: {root}")
    print(f"TOTAL_PROJECT_BYTES (excluding skipped folders): {total}")
    print("\nLIKELY_EXECUTION_SCRIPTS:")
    for size, rel in sorted(scripts, key=lambda x: x[1])[:80]:
        print(f"{size:>12}  {rel}")
    print("\nLIKELY_SEMANTIC_EXPORTS:")
    for size, rel in sorted(data, key=lambda x: (x[0], x[1]))[:120]:
        print(f"{size:>12}  {rel}")
    if not data:
        print("(none found by filename; project may save predictions under a generic filename)")
    print("\nNo files were modified or copied.")

if __name__ == "__main__":
    main()
