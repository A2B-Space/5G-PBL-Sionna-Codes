#!/usr/bin/env python3
"""Offline smoke test for the integration adapters/controller using tiny fixtures."""
from pathlib import Path
import sys
import tempfile

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from cosim.sionna_adapter import SionnaAdapter  # noqa: E402
from cosim.semantic_adapter import normalize_semantics  # noqa: E402
from cosim.controller import run_cosimulation  # noqa: E402


def main():
    with tempfile.TemporaryDirectory() as temp:
        root = Path(temp)
        dataset = root / "s6_physical_layer_dataset"
        dataset.mkdir()
        sample_id = "simple_street_canyon__pilot_trajectory__unblocked__snapshot_000"
        pd.DataFrame([
            {
                "condition": "unblocked", "snapshot": 0,
                "rx_x_m": 17.0, "rx_y_m": -13.0, "rx_z_m": 1.5,
                "tx_rx_distance_m": 63.29, "valid_path_count": 20,
                "best_beam_id": 12, "best_beam_channel_gain_db": -79.7,
                "los_blocked": False, "scene_id": "simple_street_canyon",
                "trajectory_id": "pilot_trajectory", "sample_id": sample_id,
            },
        ]).to_csv(dataset / "snapshot_metadata.csv", index=False)

        sionna = SionnaAdapter.load(root)
        assert len(sionna.snapshots) == 1
        semantics = normalize_semantics(pd.DataFrame([
            {"sample_id": sample_id, "class": "pedestrian", "confidence": 0.98, "object_id": "ped-1"},
            {"sample_id": sample_id, "class": "vehicle", "confidence": 0.92, "object_id": "veh-1"},
            {"sample_id": sample_id, "class": "background", "confidence": 0.80, "object_id": "bg-1"},
        ]))
        result = run_cosimulation(
            sionna.snapshots,
            sionna.snapshots.iloc[0],
            semantics,
            payload_budget_bytes=256,
        )
        assert result.alignment_method == "Exact sample_id join"
        assert len(result.comparison) == 3
        assert set(result.comparison["mode"]) == {
            "Conventional (fixed payload)",
            "Semantic-priority (fixed channel budget)",
            "Joint semantic + channel-aware",
        }
        assert "joint_transmitted" in result.semantic_objects.columns
        print("PASS: Sionna snapshot metadata adapter")
        print("PASS: DeepSense semantic export normalizer")
        print("PASS: sample_id synchronization")
        print("PASS: three-policy co-simulation controller")
        print(result.comparison.to_string(index=False))


if __name__ == "__main__":
    main()
