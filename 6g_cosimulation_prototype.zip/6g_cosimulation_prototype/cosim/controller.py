from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd

from .semantic_adapter import semantic_priority


@dataclass
class CoSimulationResult:
    selected_sample: dict[str, Any]
    semantic_objects: pd.DataFrame
    comparison: pd.DataFrame
    decision_log: list[str]
    alignment_method: str
    limitations: list[str]


def align_semantics(semantic_df: pd.DataFrame, sample: pd.Series, manual_frame_mapping: bool = False) -> tuple[pd.DataFrame, str]:
    sem = semantic_df.copy()
    sid = str(sample.get("sample_id", ""))
    if "sample_id" in sem and sid and (sem["sample_id"].astype(str) == sid).any():
        aligned = sem[sem["sample_id"].astype(str) == sid].copy()
        return aligned, "Exact sample_id join"

    # Stronger compound-key join when all identifiers exist.
    can_compound = (
        "scene_id" in sem and "trajectory_id" in sem and "snapshot" in sem
        and str(sample.get("scene_id", "")) not in {"", "nan"}
        and str(sample.get("trajectory_id", "")) not in {"", "nan"}
        and pd.notna(sample.get("snapshot"))
    )
    if can_compound:
        mask = (
            (sem["scene_id"].astype(str) == str(sample["scene_id"]))
            & (sem["trajectory_id"].astype(str) == str(sample["trajectory_id"]))
            & (pd.to_numeric(sem["snapshot"], errors="coerce") == int(sample["snapshot"]))
        )
        if "condition" in sem and str(sample.get("condition", "")):
            mask &= sem["condition"].astype(str).str.lower().isin([str(sample["condition"]).lower(), ""])
        aligned = sem[mask].copy()
        if not aligned.empty:
            return aligned, "scene_id + trajectory_id + snapshot join"

    # Snapshot-only is permitted only as an explicit pilot/demo mapping; caller chooses snapshot.
    if "snapshot" in sem and sem["snapshot"].notna().any():
        aligned = sem[pd.to_numeric(sem["snapshot"], errors="coerce") == int(sample["snapshot"])].copy()
        if not aligned.empty:
            return aligned, "Snapshot-only join (verify sequence and coordinate/time mapping)"
    if manual_frame_mapping:
        return sem.copy(), "Explicit manual mapping: selected semantic export assigned to selected Sionna snapshot"
    return sem.iloc[0:0].copy(), "No valid key match"


def _normalized_channel_quality(snapshots: pd.DataFrame, sample: pd.Series) -> float | None:
    if "beam_gain_db" not in snapshots or pd.isna(sample.get("beam_gain_db")):
        return None
    values = pd.to_numeric(snapshots["beam_gain_db"], errors="coerce").dropna()
    if values.empty:
        return None
    lo, hi = float(values.min()), float(values.max())
    if abs(hi - lo) < 1e-9:
        return 0.5
    return float(np.clip((float(sample["beam_gain_db"]) - lo) / (hi - lo), 0.0, 1.0))


def run_cosimulation(
    snapshots: pd.DataFrame,
    sample: pd.Series,
    semantic_df: pd.DataFrame,
    payload_budget_bytes: int = 1200,
    manual_frame_mapping: bool = False,
) -> CoSimulationResult:
    sem, alignment = align_semantics(semantic_df, sample, manual_frame_mapping=manual_frame_mapping)
    if sem.empty:
        raise ValueError(
            "No semantic records matched this Sionna sample. Use a verified sample_id/compound-key mapping or explicitly map the DeepSense frame to the selected Sionna snapshot."
        )

    sem = sem.copy()
    if "priority" not in sem:
        sem["priority"] = sem.apply(
            lambda r: semantic_priority(r.get("semantic_class", "unknown"), float(r.get("confidence", 1.0))), axis=1
        )
    sem["priority"] = pd.to_numeric(sem["priority"], errors="coerce").fillna(0.4)
    sem["confidence"] = pd.to_numeric(sem.get("confidence", 1.0), errors="coerce").fillna(1.0)

    # Lightweight application-layer packet model. It does not claim to simulate BER,
    # modulation, coding or the RF waveform.
    quality = _normalized_channel_quality(snapshots, sample)
    raw_blocked = sample.get("los_blocked", False)
    is_blocked = str(raw_blocked).strip().lower() in {"true", "1", "yes"} if pd.notna(raw_blocked) else False
    condition = str(sample.get("condition", "unknown")).lower()
    if condition == "blocked":
        is_blocked = True
    if quality is None:
        channel_budget_fraction = 0.65 if is_blocked else 0.85
    else:
        channel_budget_fraction = 0.45 + 0.55 * quality
        if is_blocked:
            channel_budget_fraction = min(channel_budget_fraction, 0.65)
    adaptive_budget = max(64, int(payload_budget_bytes * channel_budget_fraction))

    # A compact object record is modelled as ~48 B basic / ~144 B enhanced.
    sem["basic_bytes"] = 48
    sem["enhanced_bytes"] = 144
    sem["_original_order"] = np.arange(len(sem))
    sem = sem.reset_index(drop=True)

    def allocate(budget: int, priority_aware: bool, adaptive_detail: bool) -> dict[str, Any]:
        remaining = int(budget)
        delivered = []
        used = 0
        ordered = sem.sort_values("priority", ascending=False) if priority_aware else sem.sort_values("_original_order")
        for row in ordered.to_dict("records"):
            base = int(row["basic_bytes"])
            enhanced = int(row["enhanced_bytes"])
            cost = enhanced if (adaptive_detail and quality is not None and quality >= 0.55 and not is_blocked) else base
            if remaining >= cost:
                delivered.append((row, cost, "enhanced" if cost == enhanced else "basic"))
                remaining -= cost
                used += cost
            elif remaining >= base and cost > base:
                delivered.append((row, base, "basic_fallback"))
                remaining -= base
                used += base
            elif not priority_aware:
                continue
        weighted_total = float(sem["priority"].sum()) if not sem.empty else 0.0
        weighted_delivered = sum(float(item[0]["priority"]) for item in delivered)
        weighted_recall = weighted_delivered / weighted_total if weighted_total else 1.0
        return {
            "objects_delivered": len(delivered),
            "objects_total": len(sem),
            "payload_bytes": used,
            "budget_bytes": int(budget),
            "weighted_semantic_recall_pct": round(100.0 * weighted_recall, 2),
            "delivered_ids": [str(item[0].get("object_id", i)) for i, item in enumerate(delivered)],
            "details": delivered,
        }

    baseline = allocate(payload_budget_bytes, priority_aware=False, adaptive_detail=False)
    semantic_only = allocate(payload_budget_bytes, priority_aware=True, adaptive_detail=False)
    joint = allocate(adaptive_budget, priority_aware=True, adaptive_detail=True)

    comparison = pd.DataFrame([
        {"mode": "Conventional (fixed payload)", **{k: baseline[k] for k in ("objects_delivered", "objects_total", "payload_bytes", "budget_bytes", "weighted_semantic_recall_pct")}},
        {"mode": "Semantic-priority (fixed channel budget)", **{k: semantic_only[k] for k in ("objects_delivered", "objects_total", "payload_bytes", "budget_bytes", "weighted_semantic_recall_pct")}},
        {"mode": "Joint semantic + channel-aware", **{k: joint[k] for k in ("objects_delivered", "objects_total", "payload_bytes", "budget_bytes", "weighted_semantic_recall_pct")}},
    ])

    delivered_map = {str(item[0].get("object_id", i)): item[2] for i, item in enumerate(joint["details"])}
    sem["joint_delivery_level"] = sem["object_id"].astype(str).map(delivered_map).fillna("not transmitted")
    sem = sem.drop(columns=["_original_order"], errors="ignore")
    sem["joint_transmitted"] = sem["joint_delivery_level"] != "not transmitted"

    logs = [
        f"Sionna sample: {sample.get('sample_id', 'unknown')}",
        f"Semantic-to-physical alignment: {alignment}",
        f"Semantic objects received from DeepSense export: {len(sem)}",
        f"Channel condition: {condition}; LOS blocked={is_blocked}",
        f"Beamformed channel gain: {sample.get('beam_gain_db', 'not available')} dB (dimensionless gain metric, not dBm/SNR)",
        f"Relative channel quality index: {quality:.3f}" if quality is not None else "Relative channel quality index: unavailable",
        f"Adaptive application payload budget: {adaptive_budget}/{payload_budget_bytes} bytes",
        "Transmission policy: semantic importance × model confidence, with channel-conditioned payload budget/detail.",
        "Physical-layer note: this prototype evaluates an application-layer packet-budget abstraction; it does not simulate BER, modulation, coding or RF waveform transmission.",
    ]
    limits = [
        "Sionna data represents one street-canyon scene and one quasi-static 11-snapshot trajectory.",
        "The current Sionna export contains a dimensionless beamformed channel-gain metric, not calibrated received power or SNR.",
        "The semantic-to-channel transmission policy is a prototype controller, not a trained end-to-end semantic codec.",
    ]
    selected = sample.to_dict()
    selected["relative_channel_quality"] = quality
    selected["adaptive_payload_budget_bytes"] = adaptive_budget
    selected["is_blocked"] = is_blocked
    return CoSimulationResult(selected, sem, comparison, logs, alignment, limits)
