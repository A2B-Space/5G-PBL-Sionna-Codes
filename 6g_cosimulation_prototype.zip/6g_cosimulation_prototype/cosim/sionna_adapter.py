from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

import pandas as pd


@dataclass
class SionnaData:
    root: Path
    snapshots: pd.DataFrame
    beam_summary: pd.DataFrame
    tracking_comparison: pd.DataFrame
    interaction_summary: pd.DataFrame
    path_interactions: pd.DataFrame


class SionnaAdapter:
    """Read the existing S1-S8 CSV artifacts; this adapter does not rerun RT."""

    SNAPSHOT_NAMES = ("snapshot_metadata.csv",)

    @staticmethod
    def _find_file(root: Path, names: Iterable[str]) -> Path | None:
        wanted = set(names)
        # Prefer canonical S6 output locations and project-root exports.
        preferred = [
            root / "s6_physical_layer_dataset" / "snapshot_metadata.csv",
            root / "snapshot_metadata.csv",
            root / "s8_reproducibility_package" / "results" / "snapshot_metadata.csv",
        ]
        for p in preferred:
            if p.exists() and p.is_file():
                return p
        matches = []
        for p in root.rglob("*"):
            if p.is_file() and p.name in wanted:
                if any(part in {".git", ".venv", "venv", "__pycache__", "node_modules"} for part in p.parts):
                    continue
                matches.append(p)
        if not matches:
            return None
        # Prefer the generated S6 dataset directory, then shorter paths.
        matches.sort(key=lambda p: ("s6_physical_layer_dataset" not in str(p), len(p.parts)))
        return matches[0]

    @staticmethod
    def _read_optional(root: Path, filename: str) -> pd.DataFrame:
        candidates = [
            root / "s6_physical_layer_dataset" / filename,
            root / filename,
            root / "s8_reproducibility_package" / "results" / filename,
        ]
        for candidate in candidates:
            if candidate.exists():
                try:
                    return pd.read_csv(candidate)
                except Exception:
                    pass
        found = list(root.rglob(filename))
        found = [p for p in found if not any(x in {".git", ".venv", "venv", "__pycache__"} for x in p.parts)]
        if found:
            found.sort(key=lambda p: ("s6_physical_layer_dataset" not in str(p), len(p.parts)))
            try:
                return pd.read_csv(found[0])
            except Exception:
                return pd.DataFrame()
        return pd.DataFrame()

    @classmethod
    def discover_snapshot_file(cls, root: str | Path) -> Path:
        base = Path(root).expanduser().resolve()
        if not base.exists():
            raise FileNotFoundError(f"Sionna folder does not exist: {base}")
        path = cls._find_file(base, cls.SNAPSHOT_NAMES)
        if path is None:
            raise FileNotFoundError(
                f"Could not find snapshot_metadata.csv under {base}. "
                "Expected S6 physical-layer dataset or repository export."
            )
        return path

    @staticmethod
    def _first_existing(frame: pd.DataFrame, names: list[str], default=None):
        for name in names:
            if name in frame.columns:
                return frame[name]
        return default

    @classmethod
    def load(cls, root: str | Path) -> SionnaData:
        base = Path(root).expanduser().resolve()
        snapshot_file = cls.discover_snapshot_file(base)
        raw = pd.read_csv(snapshot_file)
        if raw.empty:
            raise ValueError(f"Sionna snapshot file is empty: {snapshot_file}")

        # Preserve raw columns and add normalized, display-friendly fields.
        df = raw.copy()
        aliases = {
            "scene_id": ["scene_id"],
            "trajectory_id": ["trajectory_id"],
            "condition": ["condition", "condition_id"],
            "snapshot": ["snapshot", "frame_id", "frame", "snapshot_index"],
            "sample_id": ["sample_id"],
            "rx_x_m": ["rx_x_m", "rx_x", "receiver_x"],
            "rx_y_m": ["rx_y_m", "rx_y", "receiver_y"],
            "rx_z_m": ["rx_z_m", "rx_z", "receiver_z"],
            "distance_m": ["tx_rx_distance_m", "distance_m"],
            "los_visible": ["los_visible_from_paths", "los_visible", "los"],
            "los_blocked": ["los_blocked", "blocked"],
            "valid_path_count": ["valid_path_count", "num_paths", "valid_num_paths"],
            "obstruction_intersection": ["geometric_obstruction_intersection", "obstruction_intersection"],
            "beam_gain_db": ["best_beam_channel_gain_db", "best_beam_gain_db"],
            "beam_id": ["best_beam_id", "beam_id"],
            "best_beam_regret_db": ["s5_1_regret_db", "s5_regret_db"],
            "beams_probed": ["s5_1_beams_probed", "s5_beams_probed"],
            "strongest_path_delay_ns": ["strongest_path_delay_ns", "ray_traced_los_delay_ns"],
        }
        for target, options in aliases.items():
            col = cls._first_existing(df, options)
            if col is not None:
                df[target] = col

        required = ["snapshot", "condition"]
        missing = [c for c in required if c not in df.columns]
        if missing:
            raise ValueError(f"Sionna snapshot table lacks required columns: {missing}")

        if "sample_id" not in df.columns:
            df["sample_id"] = df.apply(
                lambda r: f"{r.get('scene_id', 'scene')}__{r.get('trajectory_id', 'trajectory')}__{r['condition']}__snapshot_{int(r['snapshot']):03d}",
                axis=1,
            )
        for col in ["snapshot", "rx_x_m", "rx_y_m", "rx_z_m", "distance_m", "valid_path_count", "beam_gain_db", "beam_id", "best_beam_regret_db", "beams_probed", "strongest_path_delay_ns"]:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors="coerce")
        df["condition"] = df["condition"].astype(str).str.lower()
        df["snapshot"] = df["snapshot"].astype(int)
        df = df.sort_values(["condition", "snapshot"]).reset_index(drop=True)

        beam = cls._read_optional(base, "s7_4_beam_selection_summary.csv")
        tracking = cls._read_optional(base, "s7_5_tracking_comparison.csv")
        interactions = cls._read_optional(base, "s7_3_interaction_summary.csv")
        path_interactions = cls._read_optional(base, "interaction_records.csv")
        if path_interactions.empty:
            path_interactions = cls._read_optional(base, "s4_path_interactions.csv")

        return SionnaData(
            root=base,
            snapshots=df,
            beam_summary=beam,
            tracking_comparison=tracking,
            interaction_summary=interactions,
            path_interactions=path_interactions,
        )
