"""DeepSense 6G × Sionna RT co-simulation prototype."""
