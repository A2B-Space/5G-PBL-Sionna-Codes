from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

import pandas as pd


SKIP_DIRS = {".git", ".venv", "venv", "env", "__pycache__", "node_modules", ".idea", ".pytest_cache", "checkpoints", "weights", "models", "raw_data", "raw", "videos", "pointclouds", "cache"}
SEMANTIC_HINTS = ("semantic", "detect", "predict", "inference", "object", "result", "output", "annotation")


def discover_semantic_files(root: str | Path, max_files: int = 250) -> list[Path]:
    base = Path(root).expanduser().resolve()
    if not base.exists():
        return []
    found: list[Path] = []
    for current, dirs, files in os.walk(base):
        dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
        folder = Path(current)
        for filename in files:
            p = folder / filename
            if p.suffix.lower() not in {".csv", ".json", ".jsonl", ".parquet"}:
                continue
            try:
                if p.stat().st_size > 150 * 1024 * 1024:
                    continue
            except OSError:
                continue
            name = p.name.lower()
            if any(h in name for h in SEMANTIC_HINTS):
                found.append(p)
    found.sort(key=lambda p: ("result" not in p.name.lower() and "output" not in p.name.lower(), p.stat().st_size, len(p.parts)))
    return found[:max_files]


def _flatten_json_payload(payload: Any) -> pd.DataFrame:
    """Flatten common inference JSON layouts without assuming a model framework."""
    if isinstance(payload, list):
        if payload and all(isinstance(x, dict) for x in payload):
            return pd.json_normalize(payload)
        return pd.DataFrame()
    if not isinstance(payload, dict):
        return pd.DataFrame()

    # Typical top-level containers used by detector/export scripts.
    for key in ("detections", "predictions", "objects", "results", "instances", "semantic_objects"):
        value = payload.get(key)
        if isinstance(value, list):
            df = pd.json_normalize(value)
            for k, v in payload.items():
                if k != key and not isinstance(v, (dict, list)):
                    df[k] = v
            return df
    # Nested sequence of frames.
    for key in ("frames", "samples", "records"):
        value = payload.get(key)
        if isinstance(value, list):
            records = []
            for i, frame in enumerate(value):
                if isinstance(frame, dict):
                    nested = None
                    for object_key in ("detections", "predictions", "objects", "instances"):
                        if isinstance(frame.get(object_key), list):
                            nested = frame[object_key]
                            break
                    if nested is None:
                        records.append({"frame_index": frame.get("frame_index", frame.get("frame_id", i)), **frame})
                    else:
                        for obj in nested:
                            if isinstance(obj, dict):
                                records.append({"frame_index": frame.get("frame_index", frame.get("frame_id", i)), **obj})
            return pd.json_normalize(records)
    return pd.json_normalize(payload)


def load_semantic_file(path: str | Path) -> pd.DataFrame:
    p = Path(path).expanduser().resolve()
    if not p.exists():
        raise FileNotFoundError(p)
    suffix = p.suffix.lower()
    if suffix == ".csv":
        df = pd.read_csv(p)
    elif suffix == ".json":
        df = _flatten_json_payload(json.loads(p.read_text(encoding="utf-8")))
    elif suffix == ".jsonl":
        records = [json.loads(line) for line in p.read_text(encoding="utf-8").splitlines() if line.strip()]
        df = pd.json_normalize(records)
    elif suffix == ".parquet":
        df = pd.read_parquet(p)
    else:
        raise ValueError(f"Unsupported semantic export format: {suffix}")
    if df.empty:
        raise ValueError("Selected semantic export contains no records.")
    return normalize_semantics(df)


def _pick(df: pd.DataFrame, candidates: list[str]) -> pd.Series | None:
    lower = {str(c).lower(): c for c in df.columns}
    for c in candidates:
        if c in lower:
            return df[lower[c]]
    return None


def normalize_semantics(frame: pd.DataFrame) -> pd.DataFrame:
    df = frame.copy()
    label = _pick(df, ["class", "label", "category", "object_class", "class_name", "name", "semantic_label", "object_name"])
    if label is None:
        raise ValueError(
            "Could not identify an object class column. Expected a column such as class, label, category or object_class."
        )
    conf = _pick(df, ["confidence", "score", "probability", "conf", "class_score"])
    frame_id = _pick(df, ["snapshot", "frame_id", "frame", "frame_index", "image_id", "timestamp", "sample_id"])
    sample_id = _pick(df, ["sample_id"])
    scene_id = _pick(df, ["scene_id"])
    trajectory_id = _pick(df, ["trajectory_id", "sequence_id", "recording_id"])
    condition = _pick(df, ["condition", "condition_id"])
    object_id = _pick(df, ["object_id", "track_id", "instance_id", "id"])

    out = pd.DataFrame(index=df.index)
    out["semantic_class"] = label.astype(str)
    out["confidence"] = pd.to_numeric(conf, errors="coerce").fillna(1.0).clip(0.0, 1.0) if conf is not None else 1.0
    out["sample_id"] = sample_id.astype(str) if sample_id is not None else ""
    out["snapshot"] = pd.to_numeric(frame_id, errors="coerce") if frame_id is not None and str(frame_id.name).lower() != "sample_id" else pd.NA
    out["scene_id"] = scene_id.astype(str) if scene_id is not None else ""
    out["trajectory_id"] = trajectory_id.astype(str) if trajectory_id is not None else ""
    out["condition"] = condition.astype(str).str.lower() if condition is not None else ""
    out["object_id"] = object_id.astype(str) if object_id is not None else [str(i) for i in range(len(df))]

    # Keep useful geometry for optional visualization and matching.
    for target, names in {
        "x": ["x", "x_m", "center_x", "world_x", "position_x"],
        "y": ["y", "y_m", "center_y", "world_y", "position_y"],
        "z": ["z", "z_m", "center_z", "world_z", "position_z"],
        "x1": ["x1", "xmin", "left"],
        "y1": ["y1", "ymin", "top"],
        "x2": ["x2", "xmax", "right"],
        "y2": ["y2", "ymax", "bottom"],
    }.items():
        s = _pick(df, names)
        if s is not None:
            out[target] = pd.to_numeric(s, errors="coerce")

    out["priority"] = out.apply(
        lambda r: semantic_priority(r["semantic_class"], float(r["confidence"])), axis=1
    )
    return out.reset_index(drop=True)


def semantic_priority(label: str, confidence: float) -> float:
    name = str(label).lower()
    if any(k in name for k in ("pedestrian", "person", "human", "cyclist", "bicycle")):
        base = 1.0
    elif any(k in name for k in ("vehicle", "car", "truck", "bus", "motorcycle")):
        base = 0.85
    elif any(k in name for k in ("traffic", "sign", "signal", "obstacle", "barrier")):
        base = 0.75
    else:
        base = 0.45
    return round(base * max(0.0, min(1.0, confidence)), 4)
