from __future__ import annotations

import io
import json
import os
import sys
import tempfile
from pathlib import Path

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

PROJECT_DIR = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(PROJECT_DIR))
from cosim.controller import run_cosimulation  # noqa: E402
from cosim.semantic_adapter import discover_semantic_files, load_semantic_file, normalize_semantics, _flatten_json_payload  # noqa: E402
from cosim.sionna_adapter import SionnaAdapter  # noqa: E402

st.set_page_config(
    page_title="6G Environment-Aware Co-Simulation",
    page_icon="📡",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown("""
<style>
.block-container {padding-top: 1.2rem; padding-bottom: 2rem; max-width: 1600px;}
[data-testid="stMetric"] {background: rgba(120,120,120,.07); padding: 14px 16px; border: 1px solid rgba(128,128,128,.18); border-radius: 12px;}
section[data-testid="stSidebar"] {min-width: 330px;}
.small-muted {font-size: .85rem; opacity: .75;}
</style>
""", unsafe_allow_html=True)


def default_path(*candidates: str) -> str:
    for c in candidates:
        if Path(c).expanduser().exists():
            return str(Path(c).expanduser())
    return candidates[0] if candidates else ""


def bool_value(value) -> bool:
    if pd.isna(value):
        return False
    return str(value).strip().lower() in {"true", "1", "yes"}


def as_num(row, key, default=None):
    value = row.get(key, default)
    try:
        return float(value) if pd.notna(value) else default
    except (TypeError, ValueError):
        return default


@st.cache_data(ttl=300, show_spinner=False)
def cached_semantic_candidates(root_text: str):
    return [str(p) for p in discover_semantic_files(root_text)]


def load_semantics_from_upload(uploaded) -> pd.DataFrame:
    suffix = Path(uploaded.name).suffix.lower()
    raw = uploaded.getvalue()
    if suffix == ".csv":
        df = pd.read_csv(io.BytesIO(raw))
    elif suffix == ".json":
        df = _flatten_json_payload(json.loads(raw.decode("utf-8")))
    elif suffix == ".jsonl":
        records = [json.loads(x) for x in raw.decode("utf-8").splitlines() if x.strip()]
        df = pd.json_normalize(records)
    else:
        raise ValueError("Upload CSV, JSON or JSONL semantic export.")
    return normalize_semantics(df)


def save_run(result, filename="latest_cosimulation_result.csv"):
    out_dir = PROJECT_DIR / "results"
    out_dir.mkdir(parents=True, exist_ok=True)
    result.comparison.to_csv(out_dir / filename, index=False)


st.title("Environment-Aware Semantic Communication | 6G Co-Simulation")
st.caption("DeepSense 6G semantic outputs × Sionna RT physical-layer artifacts")
st.markdown(
    "This prototype joins exported semantic detections to keyed Sionna snapshots, "
    "then evaluates a semantic-priority and channel-conditioned application-payload policy."
)

with st.sidebar:
    st.header("Project connections")
    default_sionna = default_path("~/sionna_project", "~/5G-PBL-Sionna-Codes")
    default_deep = default_path(
        "/mnt/c/Users/nanda/EnvironmentSemanticProject",
        "~/EnvironmentSemanticProject",
    )
    sionna_root = st.text_input("Sionna project / dataset folder", value=default_sionna)
    deep_root = st.text_input("DeepSense 6G project folder", value=default_deep)
    st.caption("Folders are read in place. No ZIP or project copy is required.")
    load_button = st.button("Load / refresh project artifacts", type="primary", use_container_width=True)

if "sionna_data" not in st.session_state or load_button:
    try:
        data = SionnaAdapter.load(sionna_root)
        st.session_state.sionna_data = data
        st.session_state.sionna_root_loaded = str(data.root)
        st.session_state.load_error = None
    except Exception as exc:
        st.session_state.sionna_data = None
        st.session_state.load_error = str(exc)

if st.session_state.sionna_data is None:
    st.error("Sionna artifacts could not be loaded.")
    st.code(st.session_state.load_error or "Unknown error")
    st.info(
        "Set the Sionna folder to the local project containing "
        "s6_physical_layer_dataset/snapshot_metadata.csv (or a folder with snapshot_metadata.csv)."
    )
    st.stop()

data = st.session_state.sionna_data
snapshots = data.snapshots

# Sidebar semantic file discovery + optional export upload.
with st.sidebar:
    st.divider()
    st.header("DeepSense semantic output")
    candidate_files = [Path(p) for p in cached_semantic_candidates(deep_root)]
    if not Path(deep_root).expanduser().exists():
        st.warning("DeepSense folder path is not accessible on this machine. Upload a compact semantic CSV/JSON export, or set the correct mounted path.")
    uploaded = st.file_uploader("Upload a small semantic export (optional)", type=["csv", "json", "jsonl"])
    semantic_df = None
    semantic_source = None
    semantic_error = None
    if uploaded is not None:
        try:
            semantic_df = load_semantics_from_upload(uploaded)
            semantic_source = f"Uploaded: {uploaded.name}"
        except Exception as exc:
            semantic_error = str(exc)
    elif candidate_files:
        chosen_path = st.selectbox("Detected semantic / prediction file", candidate_files, format_func=lambda p: str(p.relative_to(Path(deep_root).expanduser().resolve())) if Path(deep_root).expanduser().exists() and Path(p).is_relative_to(Path(deep_root).expanduser().resolve()) else p.name)
        try:
            semantic_df = load_semantic_file(chosen_path)
            semantic_source = str(chosen_path)
        except Exception as exc:
            semantic_error = str(exc)
    else:
        st.warning("No obvious semantic export was auto-detected. The project itself is not modified.")
        st.caption("Look for a CSV/JSON containing object class/label and confidence, or upload that compact export above.")

    if semantic_error:
        st.error(semantic_error)
    if semantic_df is not None:
        st.success(f"Loaded {len(semantic_df)} semantic object records")
        st.caption(semantic_source)

# Header / run state
conditions = sorted(snapshots["condition"].dropna().astype(str).unique().tolist())
scene_names = snapshots["scene_id"].dropna().astype(str).unique().tolist() if "scene_id" in snapshots else []
trajectory_names = snapshots["trajectory_id"].dropna().astype(str).unique().tolist() if "trajectory_id" in snapshots else []

k1, k2, k3, k4 = st.columns(4)
k1.metric("Physical-layer samples", f"{len(snapshots)}")
k2.metric("Conditions", f"{len(conditions)}")
k3.metric("Scene", scene_names[0] if scene_names else "Available")
k4.metric("Trajectory", trajectory_names[0] if trajectory_names else "Available")
st.success(f"Sionna artifact store loaded · {st.session_state.sionna_root_loaded}")

# Main controls
control_col1, control_col2, control_col3 = st.columns([1, 1, 1.2])
with control_col1:
    selected_condition = st.selectbox("Propagation condition", conditions, index=0)
condition_rows = snapshots[snapshots["condition"] == selected_condition]
with control_col2:
    available_snapshots = sorted(condition_rows["snapshot"].dropna().astype(int).unique().tolist())
    selected_snapshot = st.selectbox("Receiver snapshot", available_snapshots, index=min(len(available_snapshots)-1, 5) if len(available_snapshots) > 5 else 0)
with control_col3:
    payload_budget = st.slider("Application payload budget (bytes)", 256, 4096, 1200, 128)

selected_rows = condition_rows[condition_rows["snapshot"].astype(int) == int(selected_snapshot)]
selected = selected_rows.iloc[0]

# Top-level tabs
tab_overview, tab_cosim, tab_channel, tab_about = st.tabs(["System overview", "Co-simulation", "Wireless channel", "Method & assumptions"])

with tab_overview:
    st.subheader("Integrated system status")
    a, b = st.columns(2)
    with a:
        st.markdown("#### DeepSense 6G")
        if semantic_df is not None:
            st.success(f"Semantic export connected · {len(semantic_df)} objects/records")
            st.caption("Source: " + str(semantic_source))
        else:
            st.warning("Project folder located / scan attempted; semantic export not yet connected")
            st.caption("The DeepSense project is not repackaged. Connect its compact inference CSV/JSON output to activate cross-modal evaluation.")
    with b:
        st.markdown("#### Sionna RT")
        st.success("Physical-layer snapshot metadata connected")
        optional_count = sum(not frame.empty for frame in [data.beam_summary, data.tracking_comparison, data.interaction_summary, data.path_interactions])
        st.caption(f"Snapshot metadata loaded; {optional_count} optional result tables found. Existing ray-tracing results are replayed from disk.")

    st.markdown("#### Selected physical-layer snapshot")
    m1, m2, m3, m4 = st.columns(4)
    m1.metric("Receiver distance", f"{as_num(selected, 'distance_m', 0):.2f} m" if as_num(selected, 'distance_m') is not None else "N/A")
    m2.metric("Valid paths", str(int(as_num(selected, "valid_path_count", 0) or 0)))
    m3.metric("Best beam ID", str(int(as_num(selected, "beam_id", 0) or 0)))
    m4.metric("Best-beam gain", f"{as_num(selected, 'beam_gain_db', 0):.2f} dB" if as_num(selected, 'beam_gain_db') is not None else "N/A")
    st.caption("The beam gain is the dimensionless |hᵀw|² metric exported by the Sionna project. It is not dBm or SNR.")

    if data.tracking_comparison is not None and not data.tracking_comparison.empty:
        st.markdown("#### Existing adaptive beam-tracking results")
        st.dataframe(data.tracking_comparison, use_container_width=True, hide_index=True)
    elif data.beam_summary is not None and not data.beam_summary.empty:
        st.dataframe(data.beam_summary, use_container_width=True, hide_index=True)

with tab_cosim:
    st.subheader("Synchronized semantic ↔ channel co-simulation")
    if semantic_df is None:
        st.warning("Connect the DeepSense semantic inference export to run the integrated controller.")
        st.markdown("**Minimum semantic export columns:** `class` or `label`; `confidence` is recommended. For automatic alignment, include `sample_id`, or `scene_id + trajectory_id + snapshot`.")
        st.markdown("For a single-frame detector output, use the explicit manual-frame mapping option below after verifying that the selected DeepSense frame corresponds to the selected Sionna snapshot.")
    else:
        st.caption(f"Semantic source: {semantic_source}")
        preview_cols = [c for c in ["semantic_class", "confidence", "object_id", "snapshot", "sample_id", "priority"] if c in semantic_df.columns]
        st.dataframe(semantic_df[preview_cols].head(15), use_container_width=True, hide_index=True)
        manual_mapping = st.checkbox(
            "Explicitly map this entire semantic export to the selected Sionna snapshot (single-frame export only)",
            value=False,
            help="Use only when all rows in this export correspond to the selected DeepSense frame and you have verified the scene/time/coordinate correspondence.",
        )
        run_col1, run_col2 = st.columns(2)
        with run_col1:
            run_selected = st.button("Run selected snapshot", type="primary", use_container_width=True)
        with run_col2:
            run_trajectory = st.button("Run aligned trajectory", use_container_width=True, disabled=manual_mapping)
        if run_selected:
            try:
                result = run_cosimulation(
                    snapshots=snapshots,
                    sample=selected,
                    semantic_df=semantic_df,
                    payload_budget_bytes=payload_budget,
                    manual_frame_mapping=manual_mapping,
                )
                st.session_state.latest_result = result
                st.session_state.latest_result_condition = selected_condition
                st.session_state.latest_result_snapshot = selected_snapshot
                save_run(result, f"cosim_{selected_condition}_snapshot_{selected_snapshot:03d}.csv")
            except Exception as exc:
                st.error(str(exc))
        if run_trajectory:
            trajectory_rows = []
            successful = 0
            skipped = 0
            with st.spinner("Evaluating keyed semantic/channel snapshot pairs..."):
                for _, sample_row in snapshots.iterrows():
                    try:
                        result_i = run_cosimulation(
                            snapshots=snapshots,
                            sample=sample_row,
                            semantic_df=semantic_df,
                            payload_budget_bytes=payload_budget,
                            manual_frame_mapping=False,
                        )
                        successful += 1
                        for _, metric_row in result_i.comparison.iterrows():
                            trajectory_rows.append({
                                "sample_id": sample_row.get("sample_id", ""),
                                "condition": sample_row.get("condition", ""),
                                "snapshot": sample_row.get("snapshot", ""),
                                **metric_row.to_dict(),
                            })
                    except ValueError:
                        skipped += 1
            if trajectory_rows:
                trajectory_result = pd.DataFrame(trajectory_rows)
                st.session_state.trajectory_result = trajectory_result
                out_dir = PROJECT_DIR / "results"
                out_dir.mkdir(parents=True, exist_ok=True)
                trajectory_result.to_csv(out_dir / "trajectory_cosimulation_results.csv", index=False)
                st.success(f"Trajectory co-simulation finished: {successful} aligned physical-layer samples; {skipped} skipped without a valid semantic join.")
            else:
                st.warning("No Sionna samples matched the keys in this semantic export. Verify sample_id or scene_id + trajectory_id + snapshot values.")

    if "trajectory_result" in st.session_state:
        st.markdown("#### Full aligned trajectory results")
        trajectory_result = st.session_state.trajectory_result
        trajectory_summary = trajectory_result.groupby("mode", as_index=False).agg(
            samples=("sample_id", "nunique"),
            mean_weighted_semantic_recall_pct=("weighted_semantic_recall_pct", "mean"),
            mean_payload_bytes=("payload_bytes", "mean"),
            mean_objects_delivered=("objects_delivered", "mean"),
        )
        st.dataframe(trajectory_summary.round(2), use_container_width=True, hide_index=True)
        st.download_button(
            "Download full-trajectory co-simulation CSV",
            data=trajectory_result.to_csv(index=False).encode("utf-8"),
            file_name="trajectory_cosimulation_results.csv",
            mime="text/csv",
        )

    if "latest_result" in st.session_state:
        result = st.session_state.latest_result
        st.divider()
        st.markdown(f"### Co-simulation result · {st.session_state.latest_result_condition} / snapshot {st.session_state.latest_result_snapshot}")
        st.success("Semantic records and Sionna channel snapshot passed through the integration controller.")
        st.info(f"Alignment: {result.alignment_method}")
        q1, q2, q3 = st.columns(3)
        q1.metric("Semantic objects", len(result.semantic_objects))
        q2.metric("Blocked condition", "Yes" if result.selected_sample["is_blocked"] else "No")
        q3.metric("Adaptive payload budget", f"{result.selected_sample['adaptive_payload_budget_bytes']} B")
        chart = px.bar(result.comparison, x="mode", y="weighted_semantic_recall_pct", title="Weighted semantic delivery (application-layer model)", text="weighted_semantic_recall_pct")
        chart.update_layout(xaxis_title="Transmission policy", yaxis_title="Weighted semantic recall (%)", yaxis_range=[0, 105])
        st.plotly_chart(chart, use_container_width=True)
        st.markdown("#### Policy comparison")
        st.dataframe(result.comparison, use_container_width=True, hide_index=True)
        st.markdown("#### Object-level joint policy decisions")
        show_cols = [c for c in ["object_id", "semantic_class", "confidence", "priority", "joint_delivery_level", "joint_transmitted"] if c in result.semantic_objects]
        st.dataframe(result.semantic_objects[show_cols], use_container_width=True, hide_index=True)
        with st.expander("Co-simulation execution log"):
            for line in result.decision_log:
                st.write("• " + line)
        with st.expander("Interpretation limits"):
            for line in result.limitations:
                st.write("• " + line)
        st.download_button(
            "Download policy comparison CSV",
            data=result.comparison.to_csv(index=False).encode("utf-8"),
            file_name=f"cosim_{st.session_state.latest_result_condition}_{st.session_state.latest_result_snapshot}.csv",
            mime="text/csv",
        )

with tab_channel:
    st.subheader("Sionna RT channel and mobility view")
    if all(c in snapshots.columns for c in ["rx_x_m", "rx_y_m", "rx_z_m"]):
        scene3d = go.Figure()
        tx_xyz = (-33.0, 11.0, 32.0)  # S1/S3 configured base-station position
        scene3d.add_trace(go.Scatter3d(
            x=[tx_xyz[0]], y=[tx_xyz[1]], z=[tx_xyz[2]], mode="markers+text",
            marker={"size": 8, "symbol": "diamond"}, text=["TX / base station"], textposition="top center",
            name="TX (configured)",
        ))
        for condition_name, part in snapshots.groupby("condition"):
            part = part.sort_values("snapshot")
            scene3d.add_trace(go.Scatter3d(
                x=part["rx_x_m"], y=part["rx_y_m"], z=part["rx_z_m"],
                mode="lines+markers", name=f"RX trajectory · {condition_name}",
                text=part.apply(lambda r: f"snapshot {int(r['snapshot'])}", axis=1),
                hovertemplate="%{text}<br>x=%{x:.2f}<br>y=%{y:.2f}<br>z=%{z:.2f}<extra></extra>",
            ))
        scene3d.add_trace(go.Scatter3d(
            x=[tx_xyz[0], as_num(selected, "rx_x_m", 0)],
            y=[tx_xyz[1], as_num(selected, "rx_y_m", 0)],
            z=[tx_xyz[2], as_num(selected, "rx_z_m", 0)],
            mode="lines", line={"dash": "dash", "width": 4}, name="TX–RX direct-geometry reference",
        ))
        # Plot true interaction vertices only when the exported table contains them.
        interaction_df = data.path_interactions
        if not interaction_df.empty and all(c in interaction_df.columns for c in ["vertex_x_m", "vertex_y_m", "vertex_z_m"]):
            subset = interaction_df.copy()
            if "condition" in subset:
                subset = subset[subset["condition"].astype(str).str.lower() == selected_condition]
            if "snapshot" in subset:
                subset = subset[pd.to_numeric(subset["snapshot"], errors="coerce") == int(selected_snapshot)]
            if not subset.empty:
                scene3d.add_trace(go.Scatter3d(
                    x=subset["vertex_x_m"], y=subset["vertex_y_m"], z=subset["vertex_z_m"],
                    mode="markers", marker={"size": 4, "symbol": "circle"},
                    name="RT path interaction points",
                    text=subset["interaction_type"] if "interaction_type" in subset else None,
                ))
        scene3d.update_layout(
            title="3D transmitter / receiver trajectory and selected snapshot",
            scene={"xaxis_title": "X (m)", "yaxis_title": "Y (m)", "zaxis_title": "Z (m)", "aspectmode": "data"},
            height=560, legend={"orientation": "h"},
        )
        st.plotly_chart(scene3d, use_container_width=True)
        st.caption("The dashed TX–RX line is a geometric reference, not a traced propagation path. RT interaction points appear only when present in the exported interaction table.")
    plot_cols = [c for c in ["rx_x_m", "beam_gain_db", "condition"] if c in snapshots.columns]
    if len(plot_cols) == 3 and snapshots["beam_gain_db"].notna().any():
        fig = px.line(
            snapshots.sort_values("rx_x_m"), x="rx_x_m", y="beam_gain_db", color="condition",
            markers=True, title="Best-beam channel gain across receiver trajectory",
            hover_data=[c for c in ["snapshot", "valid_path_count", "beam_id", "sample_id"] if c in snapshots.columns],
        )
        fig.update_layout(xaxis_title="Receiver X position (m)", yaxis_title="Best-beam channel gain (dB)")
        st.plotly_chart(fig, use_container_width=True)
    else:
        st.info("Beam-gain trajectory columns are not present in the loaded snapshot metadata.")

    left, right = st.columns(2)
    with left:
        if "valid_path_count" in snapshots:
            figp = px.line(snapshots, x="snapshot", y="valid_path_count", color="condition", markers=True, title="Valid propagation paths per snapshot")
            st.plotly_chart(figp, use_container_width=True)
    with right:
        if "beams_probed" in snapshots:
            figb = px.bar(snapshots, x="snapshot", y="beams_probed", color="condition", barmode="group", title="Adaptive beam probes per snapshot")
            st.plotly_chart(figb, use_container_width=True)

    st.markdown("#### Current snapshot diagnostics")
    cols = [c for c in ["sample_id", "scene_id", "trajectory_id", "condition", "snapshot", "rx_x_m", "rx_y_m", "rx_z_m", "distance_m", "los_visible", "los_blocked", "obstruction_intersection", "valid_path_count", "beam_id", "beam_gain_db", "best_beam_regret_db", "beams_probed"] if c in selected.index]
    st.dataframe(pd.DataFrame([selected[cols]]), use_container_width=True, hide_index=True)

with tab_about:
    st.subheader("What this prototype does — and does not claim")
    st.markdown("""
**Implemented in this dashboard**
- Loads the existing Sionna S1–S8 physical-layer artifacts from the local project folder.
- Reads DeepSense semantic inference exports in CSV, JSON or JSONL form.
- Aligns semantic records by `sample_id`, or by `scene_id + trajectory_id + snapshot`.
- Supports explicitly operator-verified single-frame mapping when the export has no join key.
- Applies a priority/confidence-based semantic selection policy and a channel-conditioned application-payload budget.
- Compares conventional, semantic-priority and joint semantic/channel-aware application-layer policies.

**Important scientific boundary**
- This first demonstrator replays the already-generated Sionna physical-layer results; it does not rerun the GPU ray tracer on every dashboard click.
- The exported best-beam metric is dimensionless channel gain, not calibrated received power or SNR.
- The packet budget is an application-layer abstraction. This version does not simulate modulation, channel coding, RF waveforms, BER or measured latency.
- The repository's S8 contract notes that semantic classes and cross-modal labels are not part of the existing Sionna dataset. The join therefore requires real DeepSense metadata or an explicitly verified manual frame mapping.
""")
    st.markdown("**Next integration extension:** replace export-file ingestion with a direct call to the DeepSense inference entry point once the local runner module/function is identified. No DeepSense model code is modified by this dashboard.")

st.divider()
st.caption("Prototype status: Sionna artifact replay available. End-to-end semantic/channel run becomes active when a valid DeepSense semantic export is connected and aligned.")
