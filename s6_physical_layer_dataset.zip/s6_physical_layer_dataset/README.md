# S6 Physical-Layer Dataset

This dataset combines the S4.1 Sionna RT path/channel export with the S5.1
beam-management replay.

## Primary record key

`scene_id + trajectory_id + condition_id + snapshot`

A `sample_id` is generated from those fields. Path records and beam
measurements are child tables keyed by `sample_id`; path interactions are
keyed by `sample_id + path_id + interaction_order`.

## Files

- `snapshot_metadata.csv`: one row per scene/trajectory/condition/snapshot.
- `path_records.csv`: one row per valid propagation path, including complex
  coefficient components, delay, AoD/AoA, Doppler, LOS and interaction summary.
- `interaction_records.csv`: one row per physical path interaction, with
  interaction type, scene object/primitive IDs and world-coordinate vertex.
- `beam_measurements.csv`: all 52 beam gains per snapshot.
- `tracking_records.csv`: S5.1 exhaustive, hold-last, fixed-local and adaptive
  tracker records.
- `tracking_summary.csv`: aggregate S5.1 metrics.
- `channel_data.npz`: complex 64-element channel vectors, beam-gain tensor,
  codebook weights/directions and sample-key arrays.
- `scene_objects.csv`: scene object IDs and names.
- `beam_codebook.csv`: 52-beam codebook and complex precoding weights.
- `manifest.json`: provenance, experiment configuration and array shapes.
- `data_dictionary.json`: table descriptions, units and key fields.
- `validation.txt`: dataset integrity checks.
- `plots/`: seven dataset QA plots in PNG/PDF and a combined PDF report.

## Interpretation notes

- The channel vector is the 64-element TX array response at the single
  baseband frequency offset used by S4.1. It is not a wideband CFR dataset.
- Beam gain is the dimensionless `abs(h^T w)^2` metric. It is not calibrated
  received power in watts or dBm.
- `obstruction_present` records the controlled concrete cuboid condition.
  `geometric_obstruction_intersection` is the geometric TX-RX segment test.
  `los_visible_from_paths` is based on the traced interaction sequence.
- The original street-canyon scene can already be NLOS without the added
  obstruction. Therefore `obstruction_present` and `los_blocked` are separate.
- Path coefficients are the Sionna passband path coefficients. CIR/CFR
  coefficients have a distinct baseband representation.
- Current data contains one spatial quasi-static trajectory with 11 positions
  and two paired environment conditions. It is not a multi-trajectory dataset.
- Do not randomly split adjacent snapshots or put paired blocked/unblocked
  versions of the same position into different splits. A valid generalization
  split requires additional independent trajectories/scenes; this release
  leaves `dataset_split` unassigned.
- The present pipeline does not contain camera frames, masks, bounding boxes,
  semantic object classes, or cross-modal correspondences.
